import pygame
from pygame.locals import QUIT
import random

VENTANA_ANCHO = 800
VENTANA_ALTO = 600

FPS = 60
BLANCO = (255, 255, 255)


class Pelota:

    # constructor
    def __init__(self, imagen_fichero):
        # cargo el fichero                               pasar el png a el tipo en el que trabaja pygame
        self.imagen = pygame.image.load(imagen_fichero).convert_alpha()
        # le da a la pelota el tamaño de la imagen png
        self.ancho, self.alto = self.imagen.get_size()

        # coordenadas de posicion
        self.x = VENTANA_ANCHO / 2 - self.ancho / 2
        self.y = VENTANA_ALTO / 2 - self.alto / 2

        # direccion hacia donde se va a mover en le punto x
        self.dir_x = random.choice([-5, 5])
        self.dir_y = random.choice([-5, 5])

        # puntuacion pelota
        self.puntuacion = 0
        self.puntuacion_ia = 0

    def mover(self):
        # altera su posicion
        self.x += self.dir_x
        self.y += self.dir_y

    def colision(self):
        if self.x <= 0:
            self.reiniciar()
            self.puntuacion_ia += 1
        if self.x + self.ancho >= VENTANA_ANCHO:
            self.reiniciar()
            self.puntuacion += 1
        if self.y <= 0:
            self.dir_y = -self.dir_y
        if self.y + self.alto >= VENTANA_ALTO:
            self.dir_y = -self.dir_y

    def reiniciar(self):
        self.x = VENTANA_ANCHO / 2 - self.ancho / 2
        self.y = VENTANA_ALTO / 2 - self.alto / 2
        self.dir_x = -self.dir_x
        self.dir_y = random.choice([-5, 5])


class Raqueta:
    def __init__(self):
        self.image = pygame.image.load("D:\\DAM\\DAM2\\pmm\\python\\PongBase\\Assets\\raqueta.png").convert_alpha()

        self.ancho, self.alto = self.image.get_size()

        self.x = 0
        self.y = VENTANA_ALTO / 2 - self.alto / 2

        self.dir_y = 0

    def mover(self):
        self.y += self.dir_y
        if self.y <= 0:
            self.y = 0

        if self.y >= VENTANA_ALTO - self.alto:
            self.y = VENTANA_ALTO - self.alto

    def golpear(self, pelota):
        # si mi pelota esta en una posicion en la que coincide con una raqueta tengo que desviarla
        if (self.x + self.ancho > pelota.x > self.x
                and pelota.y + pelota.alto > self.y
                and pelota.y < self.y + self.alto):
            pelota.dir_x = -pelota.dir_x
            pelota.x = self.x + self.ancho

    def mover_ia(self, pelota):
        if self.y >= VENTANA_ALTO - self.alto:
            self.y = VENTANA_ALTO - self.alto

        if self.y > pelota.y:
            self.dir_y = -4
        elif self.y < pelota.y:
            self.dir_y = 4
        else:
            self.dir_y = 0

        self.y += self.dir_y

    def golpear_ia(self, pelota):

        if (pelota.x + pelota.ancho > self.x
                and pelota.x < self.x + self.ancho
                and pelota.y + pelota.alto > self.y
                and pelota.y < self.y + self.alto):
            pelota.dir_x = -pelota.dir_x
            pelota.x = self.x - self.ancho


def main():
    pygame.init()

    ventana = pygame.display.set_mode((VENTANA_ANCHO, VENTANA_ALTO))

    pygame.display.set_caption("PONG")

    fuente = pygame.font.SysFont("Arial", 60)

    pelota = Pelota("D:\\DAM\\DAM2\\pmm\\python\\PongBase\\Assets\\bola_roja.png")

    raqueta_jugador = Raqueta()
    raqueta_jugador.x = 30

    raqueta_ia = Raqueta()
    raqueta_ia.x = VENTANA_ANCHO - (raqueta_ia.ancho + 30)

    jugando = True
    while jugando:

        # pido a la pelota que se mueva
        pelota.mover()
        pelota.colision()

        raqueta_jugador.mover()
        raqueta_jugador.golpear(pelota)
        raqueta_ia.mover_ia(pelota)
        raqueta_ia.golpear_ia(pelota)

        ventana.fill(BLANCO)

        ventana.blit(pelota.imagen, (pelota.x, pelota.y))

        ventana.blit(raqueta_jugador.image,
                     (raqueta_jugador.x, raqueta_jugador.y))
        ventana.blit(raqueta_ia.image, (raqueta_ia.x, raqueta_ia.y))
        texto = f" Jugador: {pelota.puntuacion}   /   IA: {pelota.puntuacion_ia}"
        letrero = fuente.render(texto, False, 'black')
        ventana.blit(letrero, (VENTANA_ANCHO / 2 - fuente.size(texto)[0] / 2, 50))

        # coger los eventos que se produzcan el pygame, en la ventana
        for evento in pygame.event.get():
            # si mi evento es de tipo quit (si el juego se cierra por el usuario), sale del bucle
            if evento.type == QUIT:
                jugando = False

            # si hemos pulsado
            if evento.type == pygame.KEYDOWN:
                # si la tecla pulsada es w, coje la tecla del evento si es w se mueve para algun lado, si es otra letra se mueve hacia otro
                # para hacerlo con las flechas
                if evento.key == pygame.K_w:
                    raqueta_jugador.dir_y = -6
                if evento.key == pygame.K_s:
                    raqueta_jugador.dir_y = 6

            # hace que frene si detecta la tecla contraria, no se mueve
            if evento.type == pygame.KEYUP:
                if evento.key == pygame.K_w:
                    raqueta_jugador.dir_y = 0
                if evento.key == pygame.K_s:
                    raqueta_jugador.dir_y = 0

        pygame.display.flip()
        # contror de tiempos, que se actualice cada cierto tiempo
        #      modulo, medoto
        pygame.time.Clock().tick(FPS)

    # fin de bucle de juego
    # cierre de sistema
    pygame.quit()


if __name__ == "__main__":
    main()
